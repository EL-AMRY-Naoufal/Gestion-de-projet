package com.fst.il.m2.Projet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetApplicationTests {

	@Test
	void contextLoads() {
	}

}
